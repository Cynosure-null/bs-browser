# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['bs_browser']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'bs-browser',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Cynosure-Null',
    'author_email': 'cynosure@disroot.org',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
